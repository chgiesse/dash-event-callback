SSE_CALLBACK_MAP = {}
WS_CALLBACK_MAP = {}

WS_CALLBACK_ENDPOINT = "/stream_dash_update_component"
SSE_CALLBACK_ENDPOINT = "/dash_update_component_sse"

STEAM_SEPERATOR = "__concatsep__"
SSE_CALLBACK_ID_KEY = "sse_callback_id"
