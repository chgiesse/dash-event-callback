from dash import hooks, Input, Output, State, set_props
from .event_callback import SSECallbackComponent, ServerSentEvent, event_callback, stream_props
from .constants import (
    SSE_CALLBACK_ENDPOINT,
    STEAM_SEPERATOR,
    SSE_CALLBACK_ID_KEY,
    SSE_CALLBACK_MAP,
)

from flask import stream_with_context, make_response, request, abort
import json


@hooks.route(SSE_CALLBACK_ENDPOINT, methods=["POST"])
def sse_component_callback():

    if "text/event-stream" not in request.accept_mimetypes:
        abort(400)

    def send_done_signal(callback_id):
        response = ["[DONE]", {}, callback_id]
        event = ServerSentEvent(json.dumps(response) + STEAM_SEPERATOR)
        return event.encode()

    def send_init_signal(callback_id):
        response = ["[INIT]", {}, callback_id]
        event = ServerSentEvent(json.dumps(response) + STEAM_SEPERATOR)
        return event.encode()

    data = request.get_json()
    content = data["content"].copy()
    ctx = content.pop("callback_context", {})
    callback_id = content.pop(SSE_CALLBACK_ID_KEY)
    callback_func = SSE_CALLBACK_MAP.get(callback_id)

    @stream_with_context
    def callback_generator():
    
        # if not callback_func:
            # yield  

        yield send_init_signal(callback_id)
        for item in callback_func(**content):
            yield item

        yield send_done_signal(callback_id)

    response = make_response(
        callback_generator(),
        {
            "Content-Type": "text/event-stream",
            "Cache-Control": "no-cache",
            "Transfer-Encoding": "chunked",
        },
    )

    response.timeout = None
    return response


@hooks.layout(priority=1)
def add_sse_component(layout):
    return (
        [SSECallbackComponent()] + layout
        if isinstance(layout, list)
        else [SSECallbackComponent(), layout]
    )


hooks.clientside_callback(
    """ //js
    function(message, processedData) {
        if (!message) { return processedData || {} };
        const DONE_TOKEN = "[DONE]";
        const INIT_TOKEN = "[INIT]";
        processedData = processedData || {};
        const setProps = window.dash_clientside.set_props;
        const messageList = message.split('__concatsep__');
        
        // Skip empty messages at the end (from the split)
        if (messageList[messageList.length - 1] === '') {
            messageList.pop();
        }
        
        // Process only new messages since last time
        const cbId = JSON.parse(messageList[0])[2]
        const startIdx = processedData[cbId] || 0;
        const newMessages = messageList.slice(startIdx);
        newMessages.forEach(messageStr => {
            try {
                const [componentId, props, callbackId] = JSON.parse(messageStr);
                if ( componentId !== DONE_TOKEN && componentId !== INIT_TOKEN ) {
                    // Set properties on the component
                    setProps(componentId, props);
                    processedData[callbackId]++;
                } 

                if ( componentId == INIT_TOKEN ) {
                    processedData[callbackId] = 1
                } 
                
                if ( componentId == DONE_TOKEN) {
                    processedData[callbackId] = 0
                }

            } catch (e) {
                console.error("Error processing message:", e, messageStr);
            }
        });

        return processedData;
    }
    ;// """,
    Output(SSECallbackComponent.ids.store, "data"),
    Input(SSECallbackComponent.ids.sse, "value"),
    State(SSECallbackComponent.ids.store, "data"),
    prevent_initial_call=True,
)

hooks.clientside_callback(
    f"""function ( pathChange ) {{
        if ( !pathChange ) {{
            return window.dash_clientside.no_update
        }}
        window.dash_clientside.set_props('{SSECallbackComponent.ids.sse}', {{done: true, url: null}});
        window.dash_clientside.set_props('{SSECallbackComponent.ids.store}', {{data: {{}}}});
    }}""",
    Input("_pages_location", "pathname", allow_optional=True),
    prevent_initial_call=True,
)
